$.extend($.fn.treegrid.defaults, {
    expanderExpandedClass: 'fa fa-chevron-down',
    expanderCollapsedClass: 'fa fa-chevron-right'
});
